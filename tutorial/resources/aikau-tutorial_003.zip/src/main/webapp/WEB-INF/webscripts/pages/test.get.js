model.jsonModel = {
   services: [],
   widgets:[
      {
         name: "alfresco/logo/Logo"
      }
   ]
};